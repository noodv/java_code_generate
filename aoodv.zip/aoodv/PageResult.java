package com.guarantee.vo;

import com.github.pagehelper.Page;
import lombok.Data;
import org.springframework.http.HttpStatus;

import java.io.Serializable;
import java.util.List;

/**
 * @description
 * @date 2017/11/14 11:15 create
 */
@Data
public class PageResult<T> implements Serializable
{

    /**
     *
     */
    private static final long serialVersionUID = 2984636422561292981L;

    private int code;
    private String msg;
    private PageVO pageVO;
    private List<T> rows;

    public PageResult()
    {
    }

    /**
     * 构造函数
     *
     * @param list
     */
    public PageResult(List<T> list)
    {
        this.code = HttpStatus.OK.value();
        this.msg = "success!";
        //分页插件的结果集
        if (list instanceof Page)
        {
            Page<T> page = (Page<T>) list;
            pageVO = new PageVO();
            pageVO.setPageNum(page.getPageNum());
            pageVO.setPageSize(page.getPageSize());
            pageVO.setTotalPages(page.getPages());
            pageVO.setTotalRows(page.getTotal());
        }
        this.rows = list;
    }

    public List<T> getRows()
    {
        return rows;
    }

    public void setRows(List<T> rows)
    {
        this.rows = rows;
    }

}
