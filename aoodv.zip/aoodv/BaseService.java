package com.guarantee.common.service;

import com.guarantee.vo.PageVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


/**
 * @author: Wang Chen Chen
 * @Date: 2018/10/23 15:05
 * @describe： 通用service 接口
 * @version: 1.0
 */

public interface BaseService<T extends PageVO, ID>
{

    int save(T record);

    int saveList(List<T> record);

    int saveSelective(T record);

    int deleteByKey(ID id);

    int deleteByPrimaryKey(ID id);

    int update(T record);

    int updateList(List<T> record);

    int count();

    int updateByPrimaryKey(T record);

    T find(T model);

    T findById(ID id);

    List<T> findList(T model);

    List<T> findListLike(T model);

    List<T> findAll();

    List<Map<String, Object>> findMapList(T obj);

    List<T> findListByIds(List<ID> ids);

    void setPage(PageVO page);

}
