package com.guarantee.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class BaseVO extends PageVO implements Serializable
{

    private String createTime;

    private String updateTime;

    private String createDate;

    /**
     * 创建人
     */
    private Integer createBy;

    private String updateDate;

    private String search;

    // 查询关键字
    private String searchWord;

    private String startDate;

    private String endDate;

}
