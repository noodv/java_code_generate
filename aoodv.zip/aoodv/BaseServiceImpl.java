package com.guarantee.common.service.impl;

import com.github.pagehelper.PageHelper;
import com.guarantee.common.mapper.BaseMapper;
import com.guarantee.common.service.BaseService;
import com.guarantee.vo.PageVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @author: Wang Chen Chen
 * @Date: 2018/10/23 16:13
 * @describe： 通用service实现类
 * @version: 1.0
 */

@Slf4j
public class BaseServiceImpl<T extends PageVO, ID, M extends BaseMapper> implements BaseService<T, ID>
{

    @Autowired
    protected M baseMapper;

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public int save(T record)
    {
        return baseMapper.save(record);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public int saveList(List<T> record)
    {
        return baseMapper.saveList(record);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public int saveSelective(T record)
    {
        return baseMapper.saveSelective(record);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public int count()
    {
        return baseMapper.count();
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public int deleteByKey(ID id)
    {
        return baseMapper.deleteByKey(id);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public int update(T record)
    {
        return baseMapper.update(record);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public int updateList(List<T> record)
    {
        return baseMapper.updateList(record);
    }

    @Override
    public T findById(ID id)
    {
        return (T) baseMapper.findById(id);
    }

    @Override
    public T find(T obj)
    {
        return (T) baseMapper.find(obj);
    }

    @Override
    public List<T> findList(T obj)
    {
        this.setPage(obj);
        return baseMapper.findList(obj);
    }

    @Override
    public List<T> findListLike(T obj)
    {
        this.setPage(obj);
        return baseMapper.findListLike(obj);
    }

    @Override
    public List<T> findAll()
    {
        return baseMapper.findAll();
    }

    @Override
    public List<Map<String, Object>> findMapList(T obj)
    {
        this.setPage(obj);
        return baseMapper.findMapList(obj);
    }

    @Override
    public int deleteByPrimaryKey(ID id)
    {
        return baseMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(T record)
    {
        return baseMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<T> findListByIds(List<ID> ids)
    {
        return baseMapper.findListByIds(ids);
    }

    @Override
    public void setPage(PageVO page)
    {
        if (page != null && page.getPageNum() != -1 && page.getPageSize() != -1)
        {
            PageHelper.startPage(page.getPageNum(), page.getPageSize());
        }
    }

}
