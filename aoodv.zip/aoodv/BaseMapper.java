package com.guarantee.common.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @author: Wang Chen Chen
 * @Date: 2018/10/26 9:42
 * @describe： 通用  Mapper 接口
 * @version: 1.0
 */
public interface BaseMapper<T, ID>
{

    // 增加
    int save(@Param("obj") T record);

    int saveList(@Param("list") T record);

    int saveSelective(T record);

    int saveList(@Param("list") List<T> record);

    // 删除
    int deleteByKey(ID id);

    int count();

    int deleteByPrimaryKey(ID id);

    // 修改
    int update(@Param("obj") T record);

    int updateList(@Param("list") List<T> record);

    int updateByPrimaryKey(@Param("obj") T record);

    // 查询
    T findById(@Param("id") ID id);

    T find(@Param("obj") T model);

    List<T> findList(@Param("obj") T model);

    List<T> findListLike(@Param("obj") T model);

    List<T> findAll();

    List<Map<String, Object>> findMapList(@Param("obj") T model);

    List<T> findListByIds(@Param("list") List<ID> ids);

}
