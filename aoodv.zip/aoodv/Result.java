package com.guarantee.vo;

import lombok.Data;
import org.springframework.http.HttpStatus;

import java.io.Serializable;

/**
 * @description
 * @date 2018/4/8 11:12 create
 */
@Data
public class Result implements Serializable
{

    private int code;
    private Object obj;
    private String msg;

    public Result()
    {
        this.code = HttpStatus.OK.value();
        this.msg = "success";
    }

    public Result(Object obj)
    {
        this.obj = obj;
        this.code = HttpStatus.OK.value();
        this.msg = "success";
    }

    public Result(int code, String msg)
    {
        this.code = code;
        this.msg = msg;
    }

    public Result(Object obj, int code, String msg)
    {
        this.obj = obj;
        this.code = code;
        this.msg = msg;
    }

    public int getCode()
    {
        return code;
    }

    public void setCode(int code)
    {
        this.code = code;
    }

    public Object getObj() {
        return obj;
    }

    public void setObj(Object obj) {
        this.obj = obj;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}