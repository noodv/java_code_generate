package com.guarantee.common.controller;

import com.guarantee.common.service.BaseService;
import com.guarantee.vo.PageVO;
import com.guarantee.vo.PageResult;
import com.guarantee.vo.Result;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author: Wang Chen Chen
 * @Date: 2018/10/23 14:16
 * @describe：
 * @version: 1.0
 */

@Log4j2
public class BaseController<T extends PageVO, ID, S extends BaseService<T, ID>>
{

    @Autowired
    protected S baseService;

    @ApiOperation(value = "新增", notes = "不需要添加id")
    @PostMapping("/save")
    public Result save(T entity)
    {
        int row = baseService.save(entity);
        return new Result(row);
    }

    @ApiOperation(value = "删除", notes = "只需要类型的id即可")
    @DeleteMapping("/delete/{id}")
    public Result delete(@PathVariable("id") ID id)
    {
        log.info("delete ID :{}", id);
        int row = baseService.deleteByKey(id);
        return new Result(row);
    }

    @ApiOperation(value = "修改", notes = "修改必须要id")
    @PutMapping("/update")
    public Result update(@RequestBody T entity)
    {
        log.info("update :{}", entity);
        int row = baseService.update(entity);
        return new Result(row);
    }

    @ApiOperation(value = "单个查询", notes = "根据Id查询")
    @GetMapping("/{id}")
    public Result findById(@PathVariable("id") ID id)
    {
        log.info("get ID : {}", id);
        T obj = baseService.findById(id);
        return new Result(obj);
    }

    @ApiOperation(value = "查询所有", notes = "分页查询所有")
    @GetMapping("find")
    public Result find(T obj)
    {
        log.info("page :{} size : {}", obj.getPageNum(), obj.getPageSize());
        T data = baseService.find(obj);
        return new Result(data);
    }

    @ApiOperation(value = "查询所有", notes = "分页查询所有")
    @GetMapping("findList")
    public PageResult findList(T obj)
    {
        log.info("page :{} size : {}", obj.getPageNum(), obj.getPageSize());
        List<T> lst = baseService.findList(obj);
        return new PageResult(lst);
    }

}
