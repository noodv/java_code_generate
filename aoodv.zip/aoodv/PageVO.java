package com.guarantee.vo;

import lombok.Data;

/**
 * @author: Wang Chen Chen
 * @Date: 2018/10/26 9:54
 * @describe：
 * @version: 1.0
 */

@Data
public class PageVO
{

    /**
     * 将当前页和每页显示数设为NULL，这样可以在Mapper查询时，判断是否为空，而来设置分页对象
     * 如果页面真的要分页，前端是会传递这两参数到后台
     */
    private Integer pageNum = -1;

    private Integer pageSize = -1;

    /**
     * 有时不用pagehelp的分页，自定义开始行，结束行时，使用
     */
    private Integer pageIndex = 0;

    private long totalRows = 0;

    private int totalPages = 0;

}
